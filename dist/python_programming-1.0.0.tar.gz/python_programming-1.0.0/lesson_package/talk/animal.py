from lesson_package.tools import utils


def sing():
    return 'gweqerewgqwgr'


def cry():
    return utils.say_twice('argaegaegr')
